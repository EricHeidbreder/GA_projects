# lab-regression_and_model_validation
Lab: Linear Regression and Model Validation
