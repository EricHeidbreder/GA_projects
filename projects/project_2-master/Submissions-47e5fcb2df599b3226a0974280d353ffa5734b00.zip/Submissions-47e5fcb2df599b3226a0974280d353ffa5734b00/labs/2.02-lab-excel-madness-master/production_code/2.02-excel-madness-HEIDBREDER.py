#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import os

# need a directory to hold csv files
try:
    os.mkdir('./output')
except: # if the output folder already exists
    print('Output folder already exists, moving on!')
    pass

files = os.listdir('./data') # make a list of the files in the data directory

# We have a .csv that has some information about the products
plu = pd.read_csv("plu-codes.csv")
plu.rename(columns={'plu_code': 'prodcode'}, inplace=True) # change `plu_code` to `prodcode` so we can merge later

# change `price_eu` to `price_usd`
eu_to_usd = lambda x: x * 1.1 # eu to usd function

# change `weight_kg` to `weight_lb`
kg_to_lb = lambda x: x * 2.2 # kg to lb function

def process_data(file, city):
    # Give us the data!
    city = pd.read_excel(f'./data/{file}', sheet_name=city)
    
    # We don't live in the EU, so we need to use less intuitive measurements
    city['price_usd'] = city['price_eu'].apply(eu_to_usd)
    city['weight_lb'] = city['weight_kg'].apply(kg_to_lb)
    
    # The prodcode means nothing to humans, we need something human-readable
    city = pd.merge(city, plu, how='inner', on='prodcode')
    
    # We don't need the EU columns anymore!
    city.drop(columns=['price_eu', 'weight_kg'], inplace=True)
    
    # Need to tell when the records were captured
    city['date'] = file.split('.')[0]
    
    # Return processed dataframe
    return city

city_dict = { # this lets us access both the city name and the eventual file name in one loop.
    "Atlanta": "atl.csv",
    "Austin": "atx.csv",
    "Boston": "bos.csv",
    "Chicago": "chi.csv",
    "Denver": "den.csv",
    "Los Angeles": "lax.csv",
    "New York": "nyc.csv",
    "San Francisco": "sf.csv",
    "Seattle": "sea.csv",
    "Washington, DC": "dc.csv"
}

for city, csv in city_dict.items():
    city_df_list = [process_data(filename, city) for filename in files] # need a list of dataframes
    city_df = pd.concat(city_df_list).reset_index(drop=True) # put them together into one large dataframe
    city_df['city'] = city # Need to be able to tell which city is which in the df
    city_df = city_df.loc[:, ["city", "date", "product", "prodcode", "quantity", "weight_lb", "price_usd"]] # reorganize columns in city_df
    city_df.to_csv(f'./output/{csv}') # creates a csv from the value in city_dict

all_cities = [pd.read_csv(f'./output/{csv_name}') for csv_name in os.listdir('./output') if '.csv' in csv_name] # need dataframes to concatenate!
all_cities = pd.concat(all_cities)




